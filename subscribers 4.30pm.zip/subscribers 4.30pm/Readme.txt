Readme:
 1.Open start.js and run
2.type url http://localhost:8080 in browser
3.First register later login.
4. You can do crud operatrions 